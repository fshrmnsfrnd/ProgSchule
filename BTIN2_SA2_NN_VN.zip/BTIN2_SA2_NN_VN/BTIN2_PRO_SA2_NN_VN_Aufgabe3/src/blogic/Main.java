/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package blogic;

/**
 *
 * @author ml
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Document doc = new Document();

        
        /*** Command: INSERT, Hallo, btin2!, pos: 0 ***/

        
        
        //Command zu MacroCommand hinzufügen 

        
        /*** Command: DELETE, pos:12, len: 1 ***/
        
        
        

        //Command zu MacroCommand hinzufügen 

        
        /*** UPPER ***/
        
        
        //Command zu MacroCommand hinzufügen 

        
        /*** UNDO MacroCommand ***/
        
        

   

    }
 
}
